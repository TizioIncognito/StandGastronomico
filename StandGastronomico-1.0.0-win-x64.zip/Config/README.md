# Configurazione dello stand

Questa cartella contiene le personalizzazioni che si possono modificare **senza ricompilare**
l'applicazione. I file vengono riletti a ogni avvio (le etichette delle categorie) o a ogni stampa
(i template).

## `categories.json` — etichette delle cinque categorie

Le categorie sono sempre cinque e il loro ordine è fisso. Il file cambia **solo il nome mostrato**;
non crea, elimina o sposta categorie. Le chiavi sono generiche e indicano la posizione, non un tipo
di cibo:

```json
{
  "cat1": "Pizzeria",
  "cat2": "Bomboloni",
  "cat3": "Primi",
  "cat4": "Secondi",
  "cat5": "Griglia"
}
```

- `cat1` = prima categoria, etichetta predefinita `Bar`
- `cat2` = seconda categoria, etichetta predefinita `Primi`
- `cat3` = terza categoria, etichetta predefinita `Secondi`
- `cat4` = quarta categoria, etichetta predefinita `Fritti`
- `cat5` = quinta categoria, etichetta predefinita `Griglia`

Regole:

- Le chiavi ammesse sono esattamente `cat1`, `cat2`, `cat3`, `cat4`, `cat5`.
- Ogni valore è un testo non vuoto, lungo al massimo 40 caratteri e diverso dagli altri.
- Gli spazi esterni vengono rimossi; le graffe `{` e `}` non sono ammesse.
- Se il file **manca**, l'applicazione usa le etichette predefinite.
- Se il file è **non valido**, l'avvio mostra un avviso con il motivo e usa le etichette predefinite.
- Le etichette valgono per Listino, Cassa e intestazioni di stampa.

Le categorie non usate restano comunque presenti nel Listino, con la loro etichetta: il file non le
nasconde e non le elimina. Se uno stand usa solo due categorie, assegna i prodotti a quelle due e
lascia vuote le altre.

## `Print/` — template della stampa

- `OrderPrint.html`: struttura e testi della stampa.
- `OrderPrint.css`: foglio di stile, incorporato nel documento al momento della stampa.

Il documento è autosufficiente: non usa Internet, font remoti o script. Per personalizzarlo basta
modificare HTML e CSS; i file vengono riletti **a ogni stampa**, quindi non serve ricompilare.

### Segnaposto del template

| Segnaposto | Significato |
|---|---|
| `{{ORDER_NUMBER}}` | Numero dell'ordine |
| `{{TIME}}` | Orario di salvataggio |
| `{{CUSTOMER_NAME}}` | Nome del cliente |
| `{{TOTAL}}` | Totale dell'ordine |
| `{{CSS}}` | Foglio di stile incorporato |
| `{{PAGE_CLASS}}` | `compact` oltre 12 righe, altrimenti vuoto |
| `{{CATEGORY_1}}` … `{{CATEGORY_5}}` | Etichetta corrente della prima…quinta categoria |
| `{{DESCRIPTION}}`, `{{QUANTITY}}`, `{{UNIT_PRICE}}`, `{{SUBTOTAL}}` | Celle dei due modelli di riga |

### Sezioni per categoria

Le sezioni della stampa si riconoscono dalla **chiave**, non dall'etichetta:

```html
<tbody data-print-category="cat2"></tbody>
```

Le chiavi sono le stesse di `categories.json`: `cat1`…`cat5`. Cambiare l'etichetta non richiede di
toccare il template. L'intestazione può usare il segnaposto corrispondente:

```html
<h2>{{CATEGORY_2}} - Ordine n. {{ORDER_NUMBER}}</h2>
```

Il template può contenere **solo le sezioni che servono**: non è obbligatorio averne cinque. Se uno
stand usa due categorie, può lasciare nel template soltanto `cat1` e `cat2`. Le righe delle categorie
senza sezione restano comunque nel riepilogo in alto.

Nel template predefinito `cat1` non ha una sezione e compare solo nel riepilogo; se serve, basta
aggiungere un `<tbody data-print-category="cat1"></tbody>` con la sua intestazione.

Sono obbligatori il contenitore del riepilogo `data-print-rows="summary"` e i due blocchi
`<template id="summary-row">` e `<template id="section-row">`: il renderer li usa per ripetere le
righe.
